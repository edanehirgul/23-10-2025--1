/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <math.h>

//  Function defiinition for f begins here

double g(double f(x), double y,double x){
    double rad135=135.0*M_PI/180.0;
    double result;
    result = (∛f(x)/(tan(rad135)+y,);
    
Float result;
 result= (x*x*x-2*x)/5.0;
 return result;
 
 
    